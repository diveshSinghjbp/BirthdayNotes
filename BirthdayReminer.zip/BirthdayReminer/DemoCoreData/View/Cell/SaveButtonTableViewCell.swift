//
//  SubmitButtonTableViewCell.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Reusable

class SaveButtonTableViewCell: UITableViewCell, NibReusable {
    @IBOutlet weak var saveButton: EAButton!
    var formCompletion: ButtonAction?
    var formItem: FormItem?
    override func awakeFromNib() {
        super.awakeFromNib()
        saveButton.style = .mainButtonLongBlue
        saveButton.setCorner()
    }
    @IBAction func submitButtonAction(_ sender: UIButton) {
        formCompletion?()
    }
    @IBOutlet weak var bottomBorderView: UIView!
}
    // MARK: - FormUpdatable
    extension SaveButtonTableViewCell: FormSubmission {
        /**
         Design of save button take action here
         
         - parameter title: String.
         - parameter style: EAButtonStyle.

         - returns: NA.
         */
        func update(_ title: String, style: EAButtonStyle) {
            saveButton.setCorner()
            saveButton.setTitle(title, for: .normal)
            saveButton.style = style
            saveButton.isEnabled = true
        }
    }
