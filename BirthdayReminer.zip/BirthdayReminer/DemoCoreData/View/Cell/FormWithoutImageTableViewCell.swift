//
//  FormWithoutImageTableViewCell.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Reusable
import SwiftValidator

class FormWithoutImageTableViewCell: UITableViewCell, NibReusable {
    @IBOutlet weak var ibTextField: GILTextField!
    @IBOutlet weak var topSeperator: UIView!
    var formItem: FormItem?
    var endEditingAction: ButtonAction?

    override func awakeFromNib() {
        super.awakeFromNib()
        ibTextField.apply(style: EAStyle.init(fontType: .regular, sizeType: .medium, colorType: .textBlack))
        ibTextField.addTarget(self, action: #selector(textFieldDidChanged(_:)), for: .editingChanged)
        ibTextField.addTarget(self, action: #selector(textFieldDidEndEditing(_:)), for: .editingDidEnd)
        topSeperator.isHidden = true
    }

    /**
     field value will be validate after enter friend name.
     
     - parameter textField: UITextField.
     
     - returns: NA.
     */
    @objc func textFieldDidChanged(_ textField: UITextField) {
        let result = formItem?.shouldValidate ?? false
        if result {
            validate()
        }
    }

    /**
     field value will be validate  when did end edting  friend name.
     
     - parameter textField: UITextField.
     
     - returns: NA.
     */
    @objc func textFieldDidEndEditing(_ textField: UITextField) {
        validate()
        formItem?.valueCompletion?(textField.text)
        endEditingAction?()
    }
    /**
     Check all validation  if item is valide or not .
     
     - parameter NA.
     
     - returns: NA.
     */
    func validate() {
        guard let item = formItem else {return}
        let rules = item.rules
        item.shouldValidate = true
        item.validator.validations.removeAll()
        item.validator.registerField(ibTextField, rules: rules)
        item.validator.validate(self)
    }
}

// MARK: - FormUpdatable
extension FormWithoutImageTableViewCell: FormUpdatable {
    /**
     field will be update with value if input text is valid.
     
     - parameter formItem: FormItem.
     
     - returns: NA.
     */
    func update(with formItem: FormItem) {
        self.formItem = formItem
        ibTextField.errorMessage = nil
        ibTextField.text = formItem.value
        ibTextField.isUserInteractionEnabled = formItem.uiProperties.isEditable
        if !formItem.uiProperties.isEditable { ibTextField.backgroundColor = EAColorType.textBlack.color
        } else {
            ibTextField.backgroundColor = .clear
        }
        ibTextField.keyboardType = formItem.uiProperties.keyboardType

        ibTextField.setup(placeholder: formItem.placeholder, title: formItem.title)
        formItem.validator.registerField(ibTextField, rules: formItem.rules)
        if let pickerManager = formItem.uiProperties.pickerManager {
            pickerManager.textField = ibTextField
        } else {
            ibTextField.inputView = nil
            ibTextField.inputAccessoryView = nil
            ibTextField.rightViewMode = .never
        }
        if formItem.isValid {
            ibTextField.errorMessage = nil
        }
    }
}

// MARK: ValidationDelegate
extension FormWithoutImageTableViewCell: ValidationDelegate {

    /**
     Form will submit if all is valid.
     
     - parameter NA.
     
     - returns: NA.
     */
    func validationSuccessful() {
        // submit the form
        ibTextField.errorMessage = nil
        formItem?.isValid = true
        formItem?.shouldValidate = false
    }

    /**
     To check failed validation.
     
     - parameter errors: [(Validatable, ValidationError)].
     
     - returns: NA.
     */
    func validationFailed(_ errors: [(Validatable, ValidationError)]) {
        // turn the fields to red
        for (field, error) in errors {
            if let field = field as? GILTextField {
                    field.errorMessage = error.errorMessage
                    formItem?.isValid = false
                    formItem?.shouldValidate = true
            }
        }
    }
}
