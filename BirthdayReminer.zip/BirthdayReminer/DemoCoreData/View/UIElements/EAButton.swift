//
//  EAButton.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import UIKit
@objc public enum EAButtonStyle: Int {

    case mainButtonLongWhite
    case mainButtonLongBlue

    public var description: String {
        return "EAButtonStyle : \(rawValue)"
    }
}

class EAButton: UIButton, SetRoundedView {

    @IBInspectable public var style = EAButtonStyle.mainButtonLongWhite {
        didSet {
            apply(buttonStyle: style)
        }
    }

    override var intrinsicContentSize: CGSize {
        switch style {
        case .mainButtonLongWhite:
            return CGSize.init(width: 250, height: 50)
        case .mainButtonLongBlue:
            return CGSize.init(width: 250, height: 50)
        }
    }

    /**
     this will apply the style on button with given configuration.
     
     - parameter buttonStyle: EAButtonStyle.
     
     - returns: NA.
     */
    private func apply(buttonStyle: EAButtonStyle) {
        switch buttonStyle {
        case .mainButtonLongWhite:
            setTitleStyle(style: .whiteButtonText, for: .normal)
            setTitleStyle(style: .whiteButtonText, for: .highlighted)
            backgroundColor = EAColorType.white.color
        case .mainButtonLongBlue:
            setTitleStyle(style: .blueButtonText, for: .normal)
            setTitleStyle(style: .blueButtonText, for: .highlighted)
            backgroundColor = EAColorType.rapidBlue.color

        }
    }

    /**
     Title Style. applied here
     
     - parameter style: EAStyle.
     - parameter state: UIControl.

     - returns: NA.
     */
    func setTitleStyle(style: EAStyle, for state: UIControl.State) {
        guard let text = title(for: .normal) else {
            return
        }
        let attibutedString = NSAttributedString.attributedString(text: text, style: style)
        setAttributedTitle(attibutedString, for: state)
    }

}

protocol SetRoundedView where Self: UIView {
}

extension SetRoundedView {

    /**
     Button style : Set corner radius  with the configuration
     
     - parameter radius: CGFloat.
     - parameter shadowColor: EAColorType.

     - returns: cellType.
     */
    func setCorner(radius: CGFloat = 25.0, shadowColor: UIColor = EAColorType.shadowColor.color) {
        layer.cornerRadius = radius
        layer.borderWidth = 1.0
        layer.borderColor = EAColorType.rapidBlue.color.cgColor
    }
}
