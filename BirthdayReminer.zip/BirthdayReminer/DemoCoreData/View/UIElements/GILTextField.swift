//
//  GILTextField.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import UIKit
import SkyFloatingLabelTextField

class GILTextField: SkyFloatingLabelTextField {

    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        titleFormatter = { (item) in
            return item
        }
    }
    override func titleLabelRectForBounds(_ bounds: CGRect, editing: Bool) -> CGRect {
        if editing {
            return CGRect(x: 0, y: -3, width: bounds.size.width, height: titleHeight())
        }
        return CGRect(x: 0, y: titleHeight(), width: bounds.size.width, height: titleHeight())
    }
}

extension SkyFloatingLabelTextField {
    /**
     this will setup text field for the friend name where we have confogure all the property.
     
     - parameter placeholder: String.
     - parameter title: String.

     - returns: NA.
     */
    public func setup(placeholder: String?, title: String) {
        self.placeholder = placeholder
        self.title = title
        font = EAFontType.regular.font(with: .compact)
        titleFont = EAFontType.regular.font(with: .small)
        placeholderColor = EAColorType.lightGray.color
        placeholderFont = EAFontType.regular.font(with: .compact)
        textColor = EAColorType.lightBlack.color
        tintColor = EAColorType.themeDarkBlue.color
        lineColor = EAColorType.lightGray.color
        selectedLineColor = EAColorType.themeDarkBlue.color
        lineHeight = 1.0
        selectedLineHeight = 2.0
    }
}
