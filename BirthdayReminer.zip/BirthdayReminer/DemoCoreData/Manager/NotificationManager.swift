//
//  NotificationManager.swift
//  DemoCoreData
//
//  Created by OPT/LPTP/335 on 24/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Foundation
import  UserNotifications

class NotificationManager: NSObject {

    /**
     add local notification on friend birthday.
     
     - parameter date: Date.
     - parameter title: String.
     
     - returns: NA.
     */
    func addnotificationFor(date: Date, name: String, identifer: String) {
        let content = UNMutableNotificationContent()
        content.title = "Today is \(name)'s birthday!!"
        content.body = Constants.Message.wish
        content.badge = 1
        var dateComponents = DateComponents()
        dateComponents.calendar = Calendar.current
        dateComponents.year = Calendar.current.component(.year, from: date)
        dateComponents.month = Calendar.current.component(.month, from: date)
        dateComponents.day = Calendar.current.component(.day, from: date)
        dateComponents.hour = 10
        dateComponents.minute = 0
        let aDate = Calendar.current.date(from: dateComponents) ?? Date()
        let triggerYearly = Calendar.current.dateComponents([.year, .month, .day, .hour], from: aDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerYearly, repeats: true)
        let request = UNNotificationRequest(identifier: Constants.Identifer.birthdayNotification + identifer, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request, withCompletionHandler: { error in
            if let error = error {
                // handle error
                print("notification failed \(error.localizedDescription)")
            } else {
                // notification set up successfully
                print("notification success")
            }
        })
    }

    func deleteNotification(identifer: String) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [Constants.Identifer.birthdayNotification + identifer])

    }
}
