//
//  CoreDataManager.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class CoreDataManager {

    static let sharedManager = CoreDataManager()
    private init() {}

    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
         */
        let container = NSPersistentContainer(name: Constants.CoreDataContainerName)
        container.loadPersistentStores(completionHandler: { (_, error) in
            if let error = error as NSError? {
                fatalError("\(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("\(nserror), \(nserror.userInfo)")
            }
        }
    }
}

extension CoreDataManager {

    /**
     fetch All Persons from DB
        
     - returns: [Person].
     */
    func fetchAllPersons() -> [Person]? {
        let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext

        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: Constants.Entity.person)
        do {
            let people = try managedContext.fetch(fetchRequest)
            return people as? [Person]
        } catch let error as NSError {
            print("\(error), \(error.userInfo)")
            return nil
        }
    }

    /**
     Update  Persons from DB
     
     - parameter aPersonData: PersonDataModel.
     - parameter person: Person.

     - returns: NA.
     */
    func updatePerson(aPersonData: PersonDataModel, person: Person) {
        let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext
        do {
            person.name = aPersonData.uiName
            person.dateofbirth = aPersonData.dob

            do {
                try managedContext.save()
            } catch let error as NSError {
                print("\(error), \(error.userInfo)")
            }
        }
    }

    /**
     Delete  Persons from DB
     
     - parameter aPersonData: PersonDataModel.

     - returns: [Person].
     */
    func deletePerson(aPersonData: PersonDataModel) -> [Person]? {

        let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext

        let fetchRequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: Constants.Entity.person)
        do {

            // Add Predicate
            let predicate = NSPredicate(format: "name CONTAINS[c] %@", aPersonData.uiName )
            fetchRequest.predicate = predicate

            let fetchedResults = try managedContext.fetch(fetchRequest)
            var arrRemovedPeople = [Person]()
            if let result = fetchedResults.first as? NSManagedObject {
                managedContext.delete(result)
            }

            do {
                try managedContext.save()
                if let result = fetchedResults.first as? Person {
                    arrRemovedPeople.append(result)
                }
                return arrRemovedPeople
            } catch let error as NSError {
                print("\(error), \(error.userInfo)")
                return nil
            } catch {
                return nil
            }

        } catch let error as NSError {
            print(error.description)
            return nil
        }
    }

    /**
     Insert  Persons into DB
     
     - parameter aPersonData: PersonDataModel.

     - returns: [Person].
     */
    func insertDataPersonTable(aPersonData: PersonDataModel) -> Person? {

        let managedContext = CoreDataManager.sharedManager.persistentContainer.viewContext

        let person = Person(context: managedContext)
        person.name = aPersonData.uiName
        person.dateofbirth = aPersonData.dob
        do {
            try managedContext.save()
            return person
        } catch let error as NSError {
            print("\(error), \(error.userInfo)")
            return nil
        }
    }

}
