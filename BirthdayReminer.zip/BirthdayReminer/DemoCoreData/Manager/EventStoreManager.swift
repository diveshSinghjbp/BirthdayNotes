//
//  EventStoreManager.swift
//  DemoCoreData
//
//  Created by OPT/LPTP/335 on 25/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit
import EventKit

class EventStoreManager: NSObject {

   static let eventStore = EKEventStore()

    /**
     check And Add Event if authorized
     
     - parameter onDate: Date.
     - parameter title: String // this is the name of friend

     - returns: NA.
     */
    func checkAndAddEvent(onDate: Date, title: String) {
        switch EKEventStore.authorizationStatus(for: .event) {
        case .authorized:
            insertEvent( date: onDate, title: title)
        case .denied:
            print(Constants.Message.NoPermission)
        case .notDetermined:
            EventStoreManager.eventStore.requestAccess(to: .event, completion: {[weak self] (granted: Bool, _: Error?) -> Void in
                if granted {
                    self?.insertEvent(date: onDate, title: title)
                } else {
                    print(Constants.Message.NoPermission)
                }
            })
        default:
            break

        }
    }
    /**
      insert event on calendar with date for a given friend name.
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    func insertEvent(date: Date, title: String) {
        let newEvent = EKEvent(eventStore: EventStoreManager.eventStore)
        newEvent.calendar = EventStoreManager.eventStore.defaultCalendarForNewEvents
        newEvent.title = title
        newEvent.notes = "\(title) - \(Constants.Message.birthday)"
        newEvent.startDate = date
        newEvent.isAllDay = true
        newEvent.endDate = date
        do {
            try EventStoreManager.eventStore.save(newEvent, span: .thisEvent)
        } catch let error as NSError {
            print("\(error.description)")
        }
    }
}
