//
//  EAPickerViewManager.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import UIKit

@objc protocol EAPickerViewManagerDelegate: class {
    @objc optional func didSelectDate(date: Date)

    @objc optional func didSelectItemAt(index: Int, sender: EAPickerViewManager)
}

enum PickerViewType {
    case dob
}

class EAPickerViewManager: NSObject {
    private let pickerView = UIPickerView()
    private let datePicker = UIDatePicker()
    var pickerData: [String]?
    var indexOfSelectedRowInPicker = 0
    let pickerType: PickerViewType
    weak var delegate: EAPickerViewManagerDelegate?
    let pickerAccessory = UIToolbar()

    weak var textField: UITextField! {
        didSet {
            switch pickerType {
            case .dob:
                textField.inputView = datePicker
                setupSideImage(name: Constants.ImageName.calendar)
            }
            textField.inputAccessoryView = pickerAccessory
        }
    }
    /**
     Return Cell Type for the index path.
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    func setupSideImage(name: String = Constants.ImageName.profiledrop) {
        let imageView = UIImageView(image: UIImage(named: name))
        imageView.frame = CGRect(x: 0, y: 0, width: imageView.frame.size.width + 15, height: imageView.frame.size.height)
        imageView.contentMode = .center
        textField.rightView = imageView
        textField.rightViewMode = .always
    }
    /**
     Return Cell Type for the index path.
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    init(with pickerType: PickerViewType) {
        self.pickerType = pickerType
        super.init()
        setPickerType()
        setupToolBarUI()
        setupToolBarButtons()
        // setupEvnet()
    }
    /**
     Return Cell Type for the index path.
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    func setPickerType() {
        switch pickerType {
        case .dob:
            datePicker.datePickerMode = UIDatePicker.Mode.date
            datePicker.maximumDate = Calendar.current.date(byAdding: .year, value: 0, to: Date()) // Five year less than today.
            datePicker.minimumDate = Calendar.current.date(byAdding: .year, value: -115, to: Date()) // 115 years less than today.
        }
    }
    /**
     setup Tool Bar UI after taking input from the picker
        
     - returns: cellType.
     */
    func setupToolBarUI() {
        pickerAccessory.autoresizingMask = .flexibleHeight
        // this customization is optional
        pickerAccessory.barStyle = .default
        pickerAccessory.barTintColor = EAColorType.rapidBlue.color
        pickerAccessory.isTranslucent = false
        var frame = pickerAccessory.frame
        frame.size.height = 44.0
        pickerAccessory.frame = frame
    }
    /**
     setup Too lBar Buttons over the picker
          
     - returns: NA.
     */
    func setupToolBarButtons() {
        let cancelButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(cancelBtnClicked(_:)))
        cancelButton.tintColor = .white
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil) // a flexible space between the two buttons
        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneBtnClicked(_:)))
        doneButton.tintColor = .white
        // Add the items to the toolbar
        pickerAccessory.items = [cancelButton, flexSpace, doneButton]
    }
    /**
     Called when the cancel button of the `pickerAccessory` was clicked. Dismsses the picker
     */
    @objc func cancelBtnClicked(_ button: UIBarButtonItem?) {
        textField?.resignFirstResponder()
    }
    /**
     Called when the done button of the `pickerAccessory` was clicked. Dismisses the picker and puts the selected value into the textField
     */
    @objc func doneBtnClicked(_ button: UIBarButtonItem?) {
        if pickerType == .dob {
            textField.text = text(for: datePicker.date)
        }
        textField?.resignFirstResponder()
        delegate?.didSelectItemAt?(index: indexOfSelectedRowInPicker, sender: self)
    }
    /**
     return text from Date
     
     - parameter date: Date.

     - returns: String].
     */
    func text(for date: Date) -> String {
        switch pickerType {
        case .dob:
            return GILDateFormatter.UIDateFormater.string(from: date)
        }
    }
}

extension EAPickerViewManager: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0 {
            // * Save to return then 'Done' button pressed
            indexOfSelectedRowInPicker = row
            textField.text = pickerData?[row]
        }
    }
    public func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData?[row]
    }
}

extension EAPickerViewManager: UIPickerViewDataSource {
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData?.count ?? 0
    }
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }

}

class GILDateFormatter {
    /**
     setup DateFormatter
     
     - parameter formatter: DateFormatter.

     - returns: NA.
     */
    private static func  setup (_ formatter: DateFormatter) {
        formatter.calendar = Calendar(identifier: .iso8601)
        formatter.timeZone = TimeZone.current
        formatter.locale = Locale(identifier: Constants.Identifer.enUSPOSIX)
    }

    static let UIDateFormater: DateFormatter = {
        let formatter = DateFormatter()
        setup(formatter)
        formatter.dateFormat = Constants.Format.date
        return formatter
    }()
}
