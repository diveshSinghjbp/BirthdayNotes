//
//  PersonDataModel.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit

extension UIColor {

    /**
     To hex string.
     
     - parameter NA.
     
     - returns: String.
     */
    func toHexString() -> String {
        var rcolor: CGFloat = 0
        var gcolor: CGFloat = 0
        var bcolor: CGFloat = 0
        var acolor: CGFloat = 0
        getRed(&rcolor, green: &gcolor, blue: &bcolor, alpha: &acolor)
        let rgb: Int = (Int)(rcolor*255)<<16 | (Int)(gcolor*255)<<8 | (Int)(bcolor*255)<<0
        return String(format: "#%06x", rgb)
    }
}

extension UIDevice {

    static var isiPad: Bool {
        return (UIDevice.current.userInterfaceIdiom == UIUserInterfaceIdiom.pad)
    }

}
