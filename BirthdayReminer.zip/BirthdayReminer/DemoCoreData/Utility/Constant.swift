//
//  Constant.swift
//  DemoCoreData
//
//  Created by OPT/LPTP/335 on 24/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Foundation
struct Constants {

    static let astric                   = "\u{002A}"
    static let blankString              = ""
    static let CoreDataContainerName    = "DemoCoreData"

    struct DataBaseKey {
        static let name                 = "name"
        static let dob                  = "dateofbirth"
    }
    struct PlaceHolder {
        static let enterFullName        = "Enter full Name"
        static let enterDOB             = "Enter Date of Birth"
    }

    struct Tilte {
        static let fullName             = "Full Name"
        static let dob                  = "Date of Birth"
    }

    struct Message {
        static let requiredField        = "This field is required"
        static let minLength            = "Must be at least 2 characters long"
        static let maxLength            = "Must be at most 50 characters long"
        static let ValidPersmission     = "Permission granted"
        static let NoPermission         = "something went wrong or we don't have permission"
        static let birthday             = "Birth day"
        static let wish                 = "Wish your friend"
    }

    struct CharLimit {
        static let minLength            = 2
        static let maxLength            = 50
    }

    struct Entity {
        static let person               =  "Person"
    }

    struct StoryBoard {
        static let main                 =  "Main"
    }

    struct Title {
        static let friendDetails        =  "friend Details"
        static let save                 =  "save"
        static let update              =  "update"
    }

    struct Identifer {
        static let cell                 =  "cell"
        static let personDataToDetail   =  "personDataToDetail"
        static let personDetailViewC    =  "PersonDetailViewController"
        static let birthdayNotification =  "birthdayNotification"
        static let enUSPOSIX            =  "en_US_POSIX"
    }
    struct Format {
        static let date                 = "MM/dd/yyyy"
        static let notiDate             = "yyyy-MM-dd HH:mm:ss"
    }

    struct ImageName {
        static let calendar             = "calendar"
        static let profiledrop          = "profiledrop"

    }
}
