//
//  PersonDataModel.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import UIKit

public enum EAFontType: String, CustomStringConvertible {

    case medium = "SFUIText-Medium"
    case light = "SFUIText-Light"
    case regular = "SFUIText-Regular"
    case bold = "SFUIText-Bold"
    case semiBold = "SFUIText-Semibold"

    public var description: String {
        return "EAStyleDescription : Font name : \(fontName)"
    }

    public var fontName: String {
        return rawValue
    }

    // Retrive font of given type. In case of failure provide system font.
    public func font(with pointSize: CGFloat) -> UIFont {
        if let font = UIFont(name: fontName, size: pointSize) {
            return font
        } else {
            return UIFont.systemFont(ofSize: pointSize)
        }
    }

    public func font(with pointSize: EASizeType) -> UIFont {
        return font(with: pointSize.fontSize)
    }
}

public enum EASizeType: CGFloat, RawRepresentable, CustomStringConvertible {

    public typealias RawValue = CGFloat
    case small
    case medium
    case compact
    public var rawValue: RawValue {
        switch self {
        case .small: return UIDevice.isiPad ? 12.0 : 12.0
        case .medium: return UIDevice.isiPad ? 14.0 : 14.0
        case .compact: return UIDevice.isiPad ? 16.0 : 16.0
        }
    }

    public var description: String {
        return "EAfont Size :\(fontSize)"
    }

    public var fontSize: CGFloat {
        return rawValue
    }
}

/**
 Color types used in our project.
 */

public enum EAColorType: String {
    case white// #FFFFFF
    case textBlack// #282D33              old:-#333333
    case lightBlack// #292929
    case lightGray// #909090
    case shadowColor// #A1ABCE4D
    case red // #E11506
    case rapidBlue // #00346B
    case themeDarkBlue // #2C7CB7
    public var color: UIColor {
        return color(for: self)
    }

    private func color(for description: EAColorType) -> UIColor {
        switch description {
        case .rapidBlue: return(UIColor(red: 0.0/255, green: 52.0/255, blue: 107.0/255, alpha: 1.0))
        case .white: return UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        case .textBlack: return UIColor(red: 40.0/255.0, green: 45.0/255.0, blue: 51.0/255.0, alpha: 1.0)
        case .lightBlack: return UIColor(red: 41.0/255.0, green: 41.0/255.0, blue: 41.0/255.0, alpha: 1.0)
        case .lightGray: return UIColor(red: 144.0/255.0, green: 144.0/255.0, blue: 144.0/255.0, alpha: 1.0)
        case .shadowColor: return UIColor(red: 161.0/255.0, green: 171.0/255.0, blue: 206.0/255.0, alpha: 0.3)
        case .red: return UIColor(red: 225.0/255.0, green: 21.0/255.0, blue: 6.0/255.0, alpha: 1.0)
        case .themeDarkBlue:
            return UIColor(red: 225.0/255.0, green: 227.0/255.0, blue: 225.0/255.0, alpha: 1.0)
        }
    }
}

open class EAStyle: CustomStringConvertible {

    fileprivate let fontType: EAFontType
    fileprivate let sizeType: EASizeType
    fileprivate let colorType: EAColorType

    public init (fontType: EAFontType, sizeType: EASizeType, colorType: EAColorType) {
        self.fontType = fontType
        self.sizeType = sizeType
        self.colorType = colorType
    }

    var font: UIFont {
        return fontType.font(with: sizeType)
    }

    open var description: String {
        return "\(fontType) : \(sizeType) : \(colorType)"
    }

    public static var whiteButtonText: EAStyle {
        return EAStyle(fontType: .regular, sizeType: .medium, colorType: .rapidBlue)
    }

    public static var blueButtonText: EAStyle {
           return EAStyle(fontType: .regular, sizeType: .medium, colorType: .white)
       }

}

// MARK: - Extentions
public extension NSAttributedString {

    static func attributedString(text: String, style: EAStyle) -> NSAttributedString {
        let font = style.font
        let textColor = style.colorType.color
        let attributedString = NSMutableAttributedString(string: text, attributes: [
            .font: font ,
            .foregroundColor: textColor] )
        return attributedString
    }
}

public extension UITextField {

    func apply(style: EAStyle) {
        font = style.font
        textColor = style.colorType.color
    }
}
