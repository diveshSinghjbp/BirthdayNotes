//
//  PersonDataModel.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit

class PersonDetailViewController: UITableViewController, UITextFieldDelegate {

    var viewModel: PersonDetailViewModel!
    var personModel = PersonDataModel()

    var person = Person()
    var submitBtnTitle = Constants.Title.save
    var shouldValidate = false
    var forUpdate = false
    weak var delegate: PersonDetailViewModelDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = Constants.Title.friendDetails
        FormItemCellType.registerCells(for: tableView)
        tableView.separatorStyle = .none
        viewModel = PersonDetailViewModel(model: personModel)
        viewModel.delegate = self
        if forUpdate {
            submitBtnTitle = Constants.Title.update
        }
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfRowsInSection(section)
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        let cellModel = viewModel.formItemCellType(for: indexPath)
        cell = cellModel.cellType.dequeueCell(for: tableView, at: indexPath)
        if let formUpdatableCell = cell as? FormUpdatable, let formItem = cellModel.formItem {
            formItem.indexPath = indexPath
            formUpdatableCell.update(with: formItem)
            formItem.uiProperties.pickerManager?.delegate = self
        }
        if var formsubmissionCell = cell as? FormSubmission {
            formsubmissionCell.update(submitBtnTitle, style: .mainButtonLongWhite)
            formsubmissionCell.formCompletion = {self.userFormSubmit()}
        }
        if let formCell = cell as? FormWithoutImageTableViewCell, shouldValidate {
            formCell.validate()
        }
        return cell
    }

    /**
     This method will call when user click on save or update button if result is not presend the it will return. it will check all the validation for all the field
     
     - parameter Na.
     
     - returns: NA.
     */
    func userFormSubmit() {
        let result = highlightVisibleCells()
        if !result {
            return
        }
        if forUpdate {
            viewModel.updateForm(person: person )
        } else {
            viewModel.submitForm()
        }

    }

    /**
     Based on validaion of visible field it will be highlited to show the error or warning to the user to know what is the error with the cell item.
     
     - parameter NA.
     
     - returns: Bool.
     */
    func highlightVisibleCells() -> Bool {
        let formItemArr = viewModel.form.formItems.filter { (item) -> Bool in
            return !item.isValid // && (item.value?.isEmpty ?? true)
        }
        guard !formItemArr.isEmpty else {
            return true
        }
        let visibleCellIndexes = formItemArr.compactMap({$0.indexPath})
        shouldValidate = true
        tableView.beginUpdates()
        tableView.reloadRows(at: visibleCellIndexes, with: .automatic)
        tableView.endUpdates()
        shouldValidate = false
        return false
    }
}

extension PersonDetailViewController: PersonDetailViewModelDelegate {

    /**
     reload Data of friend name list and will pop view controller from the entery step where we enter fiend name and DOB.
     
     - parameter NA.
     
     - returns: NA.
     */
    func reloadData() {
        delegate?.reloadData()
        self.navigationController?.popViewController(animated: true)
    }
    /**
     update Data of friend name list and will pop view controller from the entery step where we enter fiend name and DOB.
     
     - parameter NA.
     
     - returns: NA.
     */
    func update(with model: Person) {
        delegate?.update(with: model)
        self.navigationController?.popViewController(animated: true)
    }
}

extension PersonDetailViewController: EAPickerViewManagerDelegate {

    /**
     this is responsible when user select date of birth from the calendar , it will pass the data to delegate class
     
     - parameter index: Int.
     - parameter sender: EAPickerViewManager.

     - returns: cellType.
     */
    func didSelectItemAt(index: Int, sender: EAPickerViewManager) {
        let formItem = viewModel.form.formItems.first { (item) -> Bool in
            return (item.uiProperties.pickerManager == sender)
        }
        formItem?.valueCompletion?(sender.textField.text)
    }
}
