//
//  ViewController.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!

    let personDataVM = PersonDataVM()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self,
                           forCellReuseIdentifier: Constants.Identifer.cell)
        personDataVM.delegate = self

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        personDataVM.fetchAllPersons(completion: { _ in
            self.tableView.reloadData()
        })
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let target = segue.destination as? PersonDetailViewController {
            target.delegate = self
        }
    }

}
extension ViewController {
    @IBAction func addName(_ sender: Any) {
        performSegue(withIdentifier: Constants.Identifer.personDataToDetail, sender: self)
    }
}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return personDataVM.people.count
    }
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let person = personDataVM.people[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: Constants.Identifer.cell,
                                                 for: indexPath)
        cell.textLabel?.text = person.value(forKeyPath: Constants.DataBaseKey.name) as? String
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // Create a reference to the the appropriate storyboard
        let storyboard = UIStoryboard(name: Constants.StoryBoard.main, bundle: nil)
        // Instantiate the desired view controller from the storyboard using the view controllers identifier
        // Cast is as the person Detail view controller type you created in order to access it's properties and methods
        if let personDetailVC = storyboard.instantiateViewController(withIdentifier: Constants.Identifer.personDetailViewC) as? PersonDetailViewController {
            let targetController = personDataVM.updateViewController(for: indexPath, vController: personDetailVC)
            self.navigationController?.pushViewController(targetController, animated: true)
        }
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    /// update tableview method in ViewController clas
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if let person = personDataVM.people[indexPath.row] as? Person {
                NotificationManager().deleteNotification(identifer: person.objectID.uriRepresentation().absoluteString)
            }
            personDataVM.deletePerson(for: indexPath)
        }

    }
    /// update tableview method in ViewController clas
}

extension ViewController: PersonDetailViewModelDelegate {
    /**
     Call VM for update person.
     
     - parameter model: Person.
     
     - returns: NA.
     */
    func update(with model: Person) {
        personDataVM.people.append(model)
        tableView.reloadData()
    }

    /**
     reloadData after CRED opertion on friend List.
     
     - parameter NA.
     
     - returns: NA.
     */
    func reloadData() {
        tableView.reloadData()
    }

}
