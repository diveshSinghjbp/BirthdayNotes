//
//  PersonDetailViewModel.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import Reusable

protocol PersonDetailViewModelDelegate: class {
    func update(with model: Person)
    func reloadData()
}

class PersonDetailViewModel: NSObject {

    let form: PersonDetailForm!
    weak var delegate: PersonDetailViewModelDelegate?
    let notificatinManager = NotificationManager()
    let eventStoreManager = EventStoreManager()

    init(model: PersonDataModel) {
        form = PersonDetailForm(model: model)
    }

    func numberOfRowsInSection(_ section: Int) -> Int {
        return form.formItems.count + 1
    }

    /**
     Return Cell Type for the index path.
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    func formItemCellType(for indexPath: IndexPath) -> (cellType: FormItemCellType, formItem: FormItem?) {
        var tuple: (cellType: FormItemCellType, formItem: FormItem?)
        if indexPath.row >= form.formItems.count {
            tuple = (FormItemCellType.button, nil)
        } else {
            let item = form.formItems[indexPath.row]
            tuple = (item.uiProperties.cellType, item)
        }
        return tuple
    }
    /**
     submitForm after fill the input  data.
     
     - returns: cellType.
     */
    func submitForm() {
        let objModel = PersonDataModel(with: form)
        let person = CoreDataManager.sharedManager.insertDataPersonTable(aPersonData: objModel)
        if let data = person {
            delegate?.update(with: data)
        }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = Constants.Format.date
        if let date = dateFormatter.date(from: form.dob) {
            notificatinManager.addnotificationFor(date: date, name: form.name, identifer: person?.objectID.uriRepresentation().absoluteString ?? "")
            eventStoreManager.checkAndAddEvent(onDate: date, title: form.name)
        }
    }

    /////modify submit method for addnoti method
    /**
     Update user Form.
     
     - parameter person: Person.
     
     - returns: NA.
     */
    func updateForm(person: Person) {
    let objModel = PersonDataModel(with: form)
    CoreDataManager.sharedManager.updatePerson(aPersonData: objModel, person: person)
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = Constants.Format.date
    if let date = dateFormatter.date(from: form.dob) {
    notificatinManager.deleteNotification(identifer: person.objectID.uriRepresentation().absoluteString)
        notificatinManager.addnotificationFor(date: date, name: form.name, identifer: person.objectID.uriRepresentation().absoluteString)
    }
    delegate?.reloadData()
    }
}
