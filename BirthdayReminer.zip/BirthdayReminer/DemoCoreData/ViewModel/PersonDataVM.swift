//
//  PersonDataVM.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit
import CoreData

class PersonDataVM {
    var people: [NSManagedObject] = []
    weak var delegate: PersonDetailViewModelDelegate?
    typealias SaveCompletion = (([NSManagedObject]) -> Swift.Void)?

    /**
     fetch All Persons from DB.
     
     - parameter completion: SaveCompletion.
     
     - returns: NA.
     */
    func fetchAllPersons(completion: SaveCompletion) {
        if CoreDataManager.sharedManager.fetchAllPersons() != nil {
            people = CoreDataManager.sharedManager.fetchAllPersons()!
            completion?(people)
        }
    }

    /**
     delete  Persons from DB.
     
     - parameter completion: SaveCompletion.
     
     - returns: NA.
     */
    func delete(person: Person) {
        if let name = person.name, let dob = person.dateofbirth {
        let dataModel = PersonDataModel(name: name, dob: dob)
            _ = CoreDataManager.sharedManager.deletePerson(aPersonData: dataModel)
        }
    }

    /**
     update  Persons from DB.
     
     - parameter completion: SaveCompletion.
     
     - returns: NA.
     */
    func update(name: String, dob: String, person: Person) {
        let dataModel = PersonDataModel(name: name, dob: dob)
        CoreDataManager.sharedManager.updatePerson(aPersonData: dataModel, person: person)
    }

    /**
     this function will return configured View Contoller with persion details.
     
     - parameter indexPath: IndexPath.
     - parameter vController: PersonDetailViewController.

     - returns: UIViewController.
     */
    func updateViewController(for indexPath: IndexPath, vController: PersonDetailViewController) -> UIViewController {
        /*get managed object*/
        let person = people[indexPath.row]
        let firstname = person.value(forKeyPath: Constants.DataBaseKey.name) as? String ?? ""
        let dob = person.value(forKeyPath: Constants.DataBaseKey.dob) as? String ?? ""
        let persondetails = PersonDataModel(name: firstname, dob: dob)
        vController.personModel = persondetails
        if let personObj = person as? Person {
            vController.person = personObj
        }
        vController.forUpdate = true
        return vController
    }

    /**
     handle delete (by removing the data from your array and updating the tableview).
     
     - parameter indexPath: IndexPath.
     
     - returns: cellType.
     */
    func deletePerson(for indexPath: IndexPath) {
        if let person = people[indexPath.row] as? Person {
        self.delete(person: person)

        /*remove person object from array also, so that datasource have correct data*/
            if let item = (self.people.firstIndex(of: person)) {
        self.people.remove(at: item)
        delegate?.reloadData()
            }
        }
    }
}
