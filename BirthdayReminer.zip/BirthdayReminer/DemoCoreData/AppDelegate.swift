//
//  AppDelegate.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        setupLoaalNotification()
          return true
      }

    fileprivate func setupLoaalNotification() {
        // Override point for customization after application launch.
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { success, error in
            if error == nil && success {
                print(Constants.Message.ValidPersmission)
            } else {
                print(Constants.Message.NoPermission)
            }
        }
        UNUserNotificationCenter.current().delegate = self
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
           // Called when the scene has moved from an inactive state to an active state.
           // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
           UIApplication.shared.applicationIconBadgeNumber = 0
       }

}
extension AppDelegate: UNUserNotificationCenterDelegate {
    // The method will be called on the delegate only if the application is in the foreground.
    // The application can choose to have the notification presented as a sound, badge, alert and/or in the notification list.
    // This decision should be based on whether the information in the notification is otherwise visible to the user.
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .sound])// Will present an alert and will play a sound when a notification arrives
    }

}
