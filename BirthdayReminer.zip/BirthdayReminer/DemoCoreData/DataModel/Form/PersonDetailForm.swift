//
//  PersonDetailForm.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//
import SwiftValidator

class PersonDetailForm {
    var formItems = [FormItem]()
    var name: String
    var dob: String

    init() {
        name = Constants.blankString
        dob = Constants.blankString
        self.configureItems()
    }

    init(model: PersonDataModel) {
        name = model.name
        dob = model.dob
        self.configureItems()
    }

    // MARK: Form Validation
    @discardableResult
    /**
     check the validity of input text .
          
     - returns: (Bool, String?).
     */
    func isValid() -> (Bool, String?) {
        var isValid = true
        var message = String()
        let formItemArr = formItems.filter { (item) -> Bool in
            return !item.isValid && (item.value?.isEmpty ?? true)
        }
        if !formItemArr.isEmpty {
            isValid = formItemArr.first?.isValid ?? false
        }
        formItemArr.forEach { (item) in
            var text = item.placeholder ?? Constants.blankString
            text = text.replacingOccurrences(of: "\(Constants.astric)", with: Constants.blankString)
            message.append(text + ", ")
        }
        return (isValid, message)
    }

    /**
     configure cell/item for example for our requirement we are using two cell one for name and anothe for DOB.
       here we will configue and add into array
          
     - returns: NA.
     */
    private func configureItems() {
        // firstName
        let namePlaceholder = Constants.PlaceHolder.enterFullName
        let nameTitle = Constants.Tilte.fullName
        let nameItem = FormItem(placeholder: "\(namePlaceholder)\(Constants.astric)", title: "\(nameTitle)\(Constants.astric)")
        nameItem.value = name
        nameItem.rules = FormRules.name.rules
        nameItem.valueCompletion = { [weak self, weak nameItem] value in
            if let nameString = value {
            self?.name = nameString
            nameItem?.value = nameString
            }
        }

        // date of birth
        let dobPlaceHolder = Constants.PlaceHolder.enterDOB
        let dobTitle = Constants.Tilte.dob
        let dobItem = FormItem(placeholder: "\(dobPlaceHolder)\(Constants.astric)", title: "\(dobTitle)\(Constants.astric)")
        dobItem.value = dob
        dobItem.rules = FormRules.reuiredRule.rules
        dobItem.valueCompletion = { [weak self, weak dobItem] value in
            self?.dob = value!
            dobItem?.value = value
        }
        let datePickerManager = EAPickerViewManager(with: .dob)
        dobItem.uiProperties.pickerManager = datePickerManager

        formItems = [nameItem, dobItem]
    }

}
