//
//  Form.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import UIKit
import SwiftValidator

/// UIKit properties for ViewModels
class FormItemUIProperties {
    var cellType = FormItemCellType.textField
    var pickerManager: EAPickerViewManager?
    var isEditable = true
    var keyboardType = UIKeyboardType.default

}

/// Conform receiver to have data validation behavior
protocol FormValidable {
    var isValid: Bool {get set}
    var shouldValidate: Bool {get set}
    var rules: [Rule] {get set}
    var validator: Validator {get}
}

class FormRules {
    let rules: [Rule]
    var requiredRules: [Rule] {
        var ruleSet: [Rule] = [RequiredRule()]
        ruleSet.append(contentsOf: rules)
        return ruleSet
    }
    init(rules: [Rule]) {
        self.rules = rules
    }

    static let name = FormRules(rules: [RequiredRule(message: Constants.Message.requiredField),
                                        MinLengthRule(length: Constants.CharLimit.minLength, message: Constants.Message.minLength ),
                                        MaxLengthRule(length: Constants.CharLimit.maxLength, message: Constants.Message.maxLength)])

    static let reuiredRule = FormRules(rules: [RequiredRule(message: Constants.Message.requiredField)])
}

/// ViewModel to display and react to text events, to update data
class FormItem: FormValidable {
    var value: String?
    var placeholder: String?
    var title: String
    var indexPath: IndexPath?
    var valueCompletion: ((String?) -> Void)?
    // MARK: FormValidable
    let validator = Validator()
    var rules: [Rule]
    var isValid = false
    var shouldValidate = false
    let uiProperties = FormItemUIProperties()
    // MARK: Init
    init(placeholder: String? = nil, title: String, value: String? = nil) {
        self.placeholder = placeholder
        self.value = value
        self.title = title
        rules = []
    }
}
class AttributedFormItem: FormItem {
    var attributeTitle: NSAttributedString
    // MARK: Init
    init(placeholder: String? = nil, title: String, value: String? = nil, attributeTitle: NSAttributedString) {
        self.attributeTitle = attributeTitle
        super.init(placeholder: placeholder, title: title, value: value)
    }
}

/// Conform the view receiver to be updated with a form item
protocol FormUpdatable {
    func update(with formItem: FormItem)
}

typealias ButtonAction = () -> Void

protocol FormSubmission {
    var formCompletion: ButtonAction? { get set }
    func update(_ title: String, style: EAButtonStyle)
}

/// UI Cell Type to be displayed
enum FormItemCellType {
    case textField
    case button

    /// Registering methods for all forms items cell types
    ///
    /// - Parameter tableView: TableView where apply cells registration
    static func registerCells(for tableView: UITableView) {
        tableView.register(cellType: FormWithoutImageTableViewCell.self)
        tableView.register(cellType: SaveButtonTableViewCell.self)
    }
    /// Correctly dequeue the UITableViewCell according to the current cell type
    ///
    /// - Parameters:
    ///   - tableView: TableView where cells previously registered
    ///   - indexPath: indexPath where dequeue
    /// - Returns: a non-nullable UITableViewCell dequeued
    func dequeueCell(for tableView: UITableView, at indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        switch self {
        case .textField:
            cell = tableView.dequeueReusableCell(for: indexPath, cellType: FormWithoutImageTableViewCell.self)
        case .button:
            cell = tableView.dequeueReusableCell(for: indexPath, cellType: SaveButtonTableViewCell.self)
        }
        return cell
    }
}
