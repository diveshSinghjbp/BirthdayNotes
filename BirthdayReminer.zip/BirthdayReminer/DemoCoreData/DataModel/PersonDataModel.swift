//
//  PersonDataModel.swift
//  DemoCoreData
//
//  Created by optlptp183 on 22/01/21.
//  Copyright © 2021 OPTLPTP183. All rights reserved.
//

import Foundation
struct PersonDataModel: Codable {

    // Name of friend
    let name: String

    // Dob of friend
    let dob: String

    // Default constuructor
    init() {
        name = Constants.blankString
        dob  = Constants.blankString
    }

    //  constuructor with form details
    init(with form: PersonDetailForm) {
        name = form.name
        dob = form.dob
    }

    //  constuructor with form input details
    init(name: String, dob: String) {
        self.name = name
        self.dob = dob
    }

    // return name based on uiName
    var uiName: String {
        return "\(name)"
    }
}
