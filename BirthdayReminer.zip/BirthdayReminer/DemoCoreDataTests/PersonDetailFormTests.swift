//
//  PersonDetailFormTests.swift
//  enrap_iosTests
//
//  Created by Akash Pal on 14/07/20.
//  Copyright © 2020 Soumil. All rights reserved.
//

import XCTest
@testable import DemoCoreData

class PersonDetailFormTests: XCTestCase {
    var form: PersonDetailForm!
    override func setUp() {
        super.setUp()
    }
    override func tearDown() {
        super.tearDown()
    }
    // MARK: - init() without model
    func testConfigureItems() {
        form = PersonDetailForm()
        let isExist = form.formItems.contains(where: {$0.title == "Full Name\u{002A}"})
        XCTAssertTrue(isExist)
    }
    // MARK: - init() with model
    func testConfigureItems2() {
        let model = PersonDataModel(name: "Ryan Gigs", dob: "15/10/2000")
        form = PersonDetailForm(model: model )
        let isExist = form.formItems.contains(where: {$0.title == "Full Name\u{002A}"})
        XCTAssertTrue(isExist)
    }
    // MARK: - Form items completion blocks
    func testCompletionBlocks() {
        form = PersonDetailForm()
        // Full Name
        var title = "Full Name\u{002A}"
        var item = form.formItems.first(where: {$0.title == title})
        item?.valueCompletion?("John")
        XCTAssertEqual(form.name, "John")
        // Date of Birth
        title = "Date of Birth\u{002A}"
        item = form.formItems.first(where: {$0.title == title})
        item?.valueCompletion?("07/10/2010")
        XCTAssertEqual(form.dob, "07/10/2010")
    }
    func testIsValid() {
        form = PersonDetailForm()
        let result = form.isValid()
        XCTAssertFalse(result.0)
        XCTAssertNotNil(result.1)
    }
}
