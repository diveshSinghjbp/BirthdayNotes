//
//  EAButtonTests.swift
//  enrap_iosTests
//
//  Created by Akash Pal on 01/09/20.
//  Copyright © 2020 Indev. All rights reserved.
//

import XCTest
@testable import DemoCoreData

class EAButtonTests: XCTestCase {
    var button: EAButton!
    override func setUp() {
        button = EAButton(frame: CGRect(x: 50, y: 50, width: 100, height: 50))
        button.setTitle("Next", for: .normal)
    }
    override func tearDown() {
    }
    func testButtonType() {
        // mainButtonLongWhite
        button.style = .mainButtonLongWhite
        var rect = CGSize.init(width: 250, height: 50)
        XCTAssertEqual(button.style.description, "EAButtonStyle : 0")
        XCTAssertEqual(button.intrinsicContentSize, rect)
        // mainButtonLongBlue
        button.style = .mainButtonLongBlue
        rect = CGSize.init(width: 250, height: 50)
        XCTAssertEqual(button.style.description, "EAButtonStyle : 1")
        XCTAssertEqual(button.intrinsicContentSize, rect)
    }
    func testSetTitleStyle() {
        button.setTitleStyle(style: .blueButtonText, for: .normal)
        let attibutedString = NSAttributedString.attributedString(text: "Next", style: .blueButtonText)
        XCTAssertEqual(attibutedString, button.attributedTitle(for: .normal))
        // when title is not set
        let btn = EAButton()
        btn.setTitleStyle(style: .blueButtonText, for: .disabled)
        XCTAssertNotEqual(attibutedString, btn.attributedTitle(for: .disabled))
    }
    func testSetCorner() {
        button.setCorner(radius: 20)
        XCTAssertEqual(button.layer.cornerRadius, 20)
    }
}
