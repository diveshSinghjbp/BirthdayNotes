//
//  PersonDetailViewModelTests.swift
//  enrap_iosTests
//
//  Created by Akash Pal on 15/07/20.
//  Copyright © 2020 Soumil. All rights reserved.
//

import XCTest
@testable import DemoCoreData

class PersonDetailViewModelTests: XCTestCase {
    var viewModel: PersonDetailViewModel!
    let strError = "Internal error. Please try again later."
    override func setUp() {
        super.setUp()
        let model = PersonDataModel(name: "Ryan Gigs", dob: "15/10/2000")
        viewModel = PersonDetailViewModel(model: model)
    }
    override func tearDown() {
        super.tearDown()
    }
    func testNumberOfRowsInSection() {
        let row = viewModel.numberOfRowsInSection(0)
        XCTAssertEqual(row, 3)
    }
    // MARK: - index < form.formItems.count
    func testFormItemCellType() {
        let indexPath = IndexPath(row: 0, section: 0)
        let result = viewModel.formItemCellType(for: indexPath)
        XCTAssertEqual(result.cellType, .textField)
        XCTAssertNotNil(result.formItem)
    }
    // MARK: - index >= form.formItems.count
    func testFormItemCellType2() {
        let row = viewModel.form.formItems.count
        let indexPath = IndexPath(row: row, section: 0)
        let result = viewModel.formItemCellType(for: indexPath)
        XCTAssertNil(result.formItem)
        XCTAssertEqual(result.cellType, .button)
    }
}
