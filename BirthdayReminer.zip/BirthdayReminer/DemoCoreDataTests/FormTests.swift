//
//  FormTests.swift
//  enrap_iosTests
//
//  Created by Akash Pal on 16/07/20.
//  Copyright © 2020 Indev. All rights reserved.
//

import XCTest
@testable import DemoCoreData

class FormTests: XCTestCase {
    override func setUp() {
        super.setUp()
    }
    override func tearDown() {
        super.tearDown()
    }
    func testFormItemCellType() {
        let tableView = UITableView()
        let indexPath = IndexPath(row: 0, section: 0)
        FormItemCellType.registerCells(for: tableView)
        // textField
        var cell = FormItemCellType.textField.dequeueCell(for: tableView, at: indexPath)
        var isSameType = cell.isKind(of: FormWithoutImageTableViewCell.self)
        XCTAssertTrue(isSameType)
        // button
        cell = FormItemCellType.button.dequeueCell(for: tableView, at: indexPath)
        isSameType = cell.isKind(of: SaveButtonTableViewCell.self)
        XCTAssertTrue(isSameType)
    }
    func testFormItemInit() {
        let fotmItem = FormItem(title: "Test item")
        XCTAssertEqual(fotmItem.title, "Test item")
    }
    func testAttributedFormItemInit() {
        let fotmItem = AttributedFormItem(title: "Test item", attributeTitle: NSAttributedString(string: "Test attributed item"))
        XCTAssertEqual(fotmItem.attributeTitle.string, "Test attributed item")
    }

}
