//
//  EAStyleText.swift
//  enrap_iosTests
//
//  Created by Akash Pal on 01/09/20.
//  Copyright © 2020 Indev. All rights reserved.
//

import XCTest
@testable import DemoCoreData

class EAStyleTest: XCTestCase {

    override func setUp() {
    }
    override func tearDown() {
    }
    func testEAFontType() {
        // light
        var fontType = EAFontType.light
        XCTAssertEqual(fontType.fontName, "SFUIText-Light")
        // medium
        fontType = EAFontType.medium
        XCTAssertEqual(fontType.fontName, "SFUIText-Medium")
        XCTAssertEqual(fontType.description, "EAStyleDescription : Font name : SFUIText-Medium")
        // regular
        fontType = EAFontType.regular
        XCTAssertEqual(fontType.fontName, "SFUIText-Regular")
        XCTAssertEqual(fontType.description, "EAStyleDescription : Font name : SFUIText-Regular")
        // semiBold
        fontType = EAFontType.semiBold
        XCTAssertEqual(fontType.fontName, "SFUIText-Semibold")
        XCTAssertEqual(fontType.description, "EAStyleDescription : Font name : SFUIText-Semibold")
        // bold
        fontType = EAFontType.bold
        XCTAssertEqual(fontType.fontName, "SFUIText-Bold")
        XCTAssertEqual(fontType.description, "EAStyleDescription : Font name : SFUIText-Bold")
    }
    func testEASizeType() {
        // small
        var sizeType = EASizeType.small
        XCTAssertEqual(sizeType.description, "EAfont Size :12.0")
        // medium
        sizeType = EASizeType.medium
        XCTAssertEqual(sizeType.description, "EAfont Size :14.0")
        // compact
        sizeType = EASizeType.compact
        XCTAssertEqual(sizeType.description, "EAfont Size :16.0")
    }
    func testEAColorType() {
        // themeDarkBlue
        var expect = UIColor(red: 225.0/255.0, green: 227.0/255.0, blue: 225.0/255.0, alpha: 1.0)
        var result = EAColorType.themeDarkBlue.color
        XCTAssertEqual(expect, result)
        // rapidBlue
        expect = UIColor(red: 0.0/255, green: 52.0/255, blue: 107.0/255, alpha: 1.0)
        result = EAColorType.rapidBlue.color
        XCTAssertEqual(expect, result)
        // white
        expect = UIColor(red: 255.0/255.0, green: 255.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        result = EAColorType.white.color
        XCTAssertEqual(expect, result)
        // textBlack
        expect = UIColor(red: 40.0/255.0, green: 45.0/255.0, blue: 51.0/255.0, alpha: 1.0)
        result = EAColorType.textBlack.color
        XCTAssertEqual(expect, result)
        // lightBlack
        expect = UIColor(red: 41.0/255.0, green: 41.0/255.0, blue: 41.0/255.0, alpha: 1.0)
        result = EAColorType.lightBlack.color
        XCTAssertEqual(expect, result)
        // lightGray
        expect = UIColor(red: 144.0/255.0, green: 144.0/255.0, blue: 144.0/255.0, alpha: 1.0)
        result = EAColorType.lightGray.color
        XCTAssertEqual(expect, result)
        // shadowColor
        expect = UIColor(red: 161.0/255.0, green: 171.0/255.0, blue: 206.0/255.0, alpha: 0.3)
        result = EAColorType.shadowColor.color
        XCTAssertEqual(expect, result)
    }
    func testEAStyle() {
        // whiteButtonText
        var style = EAStyle.whiteButtonText
        XCTAssertEqual(style.font.fontName, ".SFUI-Regular")
        style = EAStyle.blueButtonText
        XCTAssertEqual(style.font.fontName, ".SFUI-Regular")
    }
    // MARK: - Test NSAttributedString extension
    func testAttributedString() {
        let result = NSAttributedString.attributedString(text: "Attributed text", style: .blueButtonText)
        XCTAssertEqual(result.string, "Attributed text")
    }
    // MARK: - Test apply() method
    func testApply() {
        let textField = UITextField()
        textField.apply(style: .blueButtonText)
        let fontName1 = textField.font!.fontName
        XCTAssertEqual(fontName1, ".SFUI-Regular")
        XCTAssertEqual(textField.textColor, EAColorType.white.color)
    }
}
